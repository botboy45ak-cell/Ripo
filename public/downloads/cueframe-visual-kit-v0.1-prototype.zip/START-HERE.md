# Cueframe prototype — start here

**Version:** 0.1 prototype  
**For:** short-form video creators using phone or desktop editors  
**Status:** sample for review and device testing; not a commercial release

Cueframe contains transparent visual overlays for adding structure to a short video. Choose an aspect ratio, choose a visual style, then import the PNG that fits the moment. Add your own words in your video editor; the PNGs intentionally avoid baked-in language.

## Included

- `assets/png/vertical/` — portrait 9:16 PNGs, 1080×1920 pixels.
- `assets/png/wide/` — landscape 16:9 PNGs, 1920×1080 pixels.
- `assets/svg/` — optional editable vector source. The PNG files are the easiest format to use in an editor.
- `guides/` — phone, desktop, and general workflows.
- `preview.html` — a local gallery. Open it in a browser after extracting the ZIP.
- `planner.html` — an offline, responsive storyboard builder with downloadable time-coded plans.
- `ASSET-CATALOG.json` — file names, dimensions, and intended uses.

## Try the offline planner

Open `planner.html` in a browser and choose a format, target length, visual style, and frame shape. Select **Load a filled example** to see one of four completed sample plans (a school-bag check, a timer-based reading demo, a paper-vs-phone-note comparison, or a desk reset story). Edit the narration and shot notes, then download the plan as text or use the print dialog. The planner makes no network requests; it does not generate a finished video or verify facts for you.

## Pick an aspect ratio

Use the portrait files for a vertical 9:16 project. Use the wide files for a horizontal 16:9 project. The dimensions are exact canvas sizes; the asset artwork is placed within a transparent canvas so you can position and time it like a normal image layer.

## Pick a visual style

- **Clear** — calm cool accents for tutorials, explainers, lessons, and demos.
- **Pulse** — energetic accents for gaming, tech, reaction, and fast-cut edits.
- **Warm** — warm accents for lifestyle, food, travel, and personal stories.

These are starting points, not rigid rules. Try each one over a short copy of your footage and keep whichever is easiest to read.

## Before using

This is a prototype. Check the attached draft license and test the files in your own editor and device before relying on them. The guide buttons can move between app releases. PNGs should be composited as ordinary image layers; no blend mode or plugin is required. Exact rendering and project performance depend on the editor and device.

The product name is a working title and has not had a trademark search. The files are original vector artwork for this prototype; do not describe the product as affiliated with CapCut or any other editor.
